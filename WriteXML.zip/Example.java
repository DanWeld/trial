import parser.XmlJsonParser;
import parser.ParserException;

/******  Example using XML parser from jar file ******/
public class Example
{
  public static void main(String[] args)
  {
    StudentList studentList = new StudentList();

    Student s1 = new Student("Bob", "Bobson", "Denmark");
    Student s2 = new Student("Bob2", "Bobson", "Denmark");
    Student s3 = new Student("Bob3", "Bobson", "Denmark");

    studentList.add(s1);
    studentList.add(s2);
    studentList.add(s3);

    XmlJsonParser parser = new XmlJsonParser();

    //write the XML file
    try
    {
      parser.toXml(studentList, "list.xml");
    }
    catch (ParserException e)
    {
      e.printStackTrace();
    }

    //read the XML file
    try
    {
      StudentList list = parser.fromXml("list.xml", StudentList.class);
      System.out.println(list);
    }
    catch (ParserException e)
    {
      e.printStackTrace();
    }
  }
}
